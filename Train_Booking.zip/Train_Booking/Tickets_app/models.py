from django.db import models
from pymongo import MongoClient 

con=MongoClient("mongodb+srv://bnivedha400_db_user:xilZAchSySuoql4f@cluster0.dz4he2r.mongodb.net/?appName=Cluster0")
db=con["trains"]
col=db["Booking"]








# from django.db import models
# from pymongo import MongoClient 


# client = MongoClient("mongodb+srv://bnivedha400_db_user:xilZAchSySuoql4f@cluster0.dz4he2r.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# db = client["Train_Booking"]
# col = db["Train"]



# col.insert_many([
# {
# "train_no":"12621",
# "train_name":"Tamil Nadu Express",
# "source":"Chennai",
# "destination":"Delhi",
# "departure_time":"22:00",
# "arrival_time":"06:30",
# "classes":{"SL":850,"3AC":1850,"2AC":2750,"1AC":4500},
# "seats":{"SL":180,"3AC":90,"2AC":50,"1AC":20}
# },
# {
# "train_no":"12627",
# "train_name":"Karnataka Express",
# "source":"Chennai",
# "destination":"Bangalore",
# "departure_time":"06:30",
# "arrival_time":"13:45",
# "classes":{"SL":350,"3AC":950,"2AC":1450,"1AC":2400},
# "seats":{"SL":150,"3AC":80,"2AC":40,"1AC":20}
# },
# {
# "train_no":"12655",
# "train_name":"Navjeevan Express",
# "source":"Chennai",
# "destination":"Ahmedabad",
# "departure_time":"09:15",
# "arrival_time":"08:20",
# "classes":{"SL":720,"3AC":1650,"2AC":2500,"1AC":4200},
# "seats":{"SL":170,"3AC":85,"2AC":45,"1AC":18}
# },
# {
# "train_no":"12637",
# "train_name":"Pandian Express",
# "source":"Chennai",
# "destination":"Madurai",
# "departure_time":"21:40",
# "arrival_time":"05:50",
# "classes":{"SL":260,"3AC":780,"2AC":1200,"1AC":2000},
# "seats":{"SL":160,"3AC":75,"2AC":35,"1AC":15}
# },
# {
# "train_no":"12673",
# "train_name":"Cheran Express",
# "source":"Chennai",
# "destination":"Coimbatore",
# "departure_time":"22:15",
# "arrival_time":"06:45",
# "classes":{"SL":300,"3AC":850,"2AC":1350,"1AC":2200},
# "seats":{"SL":155,"3AC":70,"2AC":36,"1AC":16}
# },
# {
# "train_no":"12601",
# "train_name":"Mangalore Mail",
# "source":"Chennai",
# "destination":"Mangalore",
# "departure_time":"20:10",
# "arrival_time":"11:30",
# "classes":{"SL":480,"3AC":1200,"2AC":1800,"1AC":3000},
# "seats":{"SL":145,"3AC":65,"2AC":32,"1AC":14}
# },
# {
# "train_no":"12711",
# "train_name":"Pinakini Express",
# "source":"Chennai",
# "destination":"Vijayawada",
# "departure_time":"14:00",
# "arrival_time":"21:30",
# "classes":{"SL":340,"3AC":900,"2AC":1400,"1AC":2300},
# "seats":{"SL":165,"3AC":82,"2AC":38,"1AC":18}
# },
# {
# "train_no":"12695",
# "train_name":"Pearl City Express",
# "source":"Chennai",
# "destination":"Tuticorin",
# "departure_time":"19:30",
# "arrival_time":"06:10",
# "classes":{"SL":340,"3AC":900,"2AC":1450,"1AC":2400},
# "seats":{"SL":150,"3AC":70,"2AC":35,"1AC":15}
# },
# {
# "train_no":"12633",
# "train_name":"Kanyakumari Express",
# "source":"Chennai",
# "destination":"Kanyakumari",
# "departure_time":"17:20",
# "arrival_time":"08:40",
# "classes":{"SL":450,"3AC":1150,"2AC":1750,"1AC":2900},
# "seats":{"SL":175,"3AC":88,"2AC":42,"1AC":20}
# },
# {
# "train_no":"12679",
# "train_name":"Coimbatore Intercity",
# "source":"Chennai",
# "destination":"Coimbatore",
# "departure_time":"07:15",
# "arrival_time":"14:30",
# "classes":{"SL":320,"3AC":820,"2AC":1300,"1AC":2100},
# "seats":{"SL":140,"3AC":68,"2AC":34,"1AC":12}
# },


# {
#   "train_no": "16180",
#   "train_name": "Mannai Express",
#   "source": "Coimbatore",
#   "destination": "Mannargudi",
#   "departure_time": "20:30",
#   "arrival_time": "06:45",
#   "classes":{"SL":350,"3AC":900,"2AC":1450,"1AC":2300},
#   "seats":{"SL":140,"3AC":68,"2AC":50,"1AC":70}
  
# }
# ])

































